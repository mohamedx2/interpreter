﻿# Hamroun French Programming Language - Windows Distribution

##  IMPORTANT - Problèmes de Compatibilité Windows

### Si vous voyez "Cette application ne peut pas s'exécuter sur votre PC":

**C'est un problème courant avec Windows SmartScreen. Voici les solutions :**

####  Solution 1 - Débloquer le fichier :
1. Clic droit sur hamroun-32bit.exe ou hamroun-64bit.exe
2. Sélectionnez "Propriétés"
3. Dans l'onglet "Général", cochez "Débloquer"
4. Cliquez "OK"
5. Essayez d'exécuter à nouveau

####  Solution 2 - Contourner SmartScreen :
1. Double-cliquez sur l'exécutable
2. Si Windows affiche un avertissement, cliquez "Plus d'infos"
3. Cliquez "Exécuter quand même"

####  Solution 3 - Utiliser la version 32-bit :
Si la version 64-bit ne fonctionne pas, essayez hamroun-32bit.exe

##  Contenu de cette distribution

### Exécutables :
- hamroun-64bit.exe - Version 64-bit (recommandée)
- hamroun-32bit.exe - Version 32-bit (plus compatible)

### Fichiers d'exemple :
- simple.hamroun - Programme simple pour commencer
- demo.hamroun - Démonstration complète

##  Utilisation

### Premier test :
hamroun-32bit.exe simple.hamroun

##  Ces fichiers sont sûrs
Créés par Mohamed Ali Hamroun (@mohamedx2)
Code source disponible sur GitHub
